package com.example.work.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.work.R
import com.example.work.UsageBackgroundService
import com.example.work.data.UsageTracker

class MenuFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val v = inflater.inflate(R.layout.fragment_menu, container, false)

        // 導航按鈕
        v.findViewById<Button>(R.id.btnAttendance).setOnClickListener {
            findNavController().navigate(R.id.attendanceFragment)
        }
        v.findViewById<Button>(R.id.btnLogin).setOnClickListener {
            findNavController().navigate(R.id.loginFragment)
        }
        v.findViewById<Button>(R.id.btnFood).setOnClickListener {
            findNavController().navigate(R.id.foodFragment)
        }
        v.findViewById<Button>(R.id.btnStats).setOnClickListener {
            findNavController().navigate(R.id.statsFragment)
        }

        // ✅ 開始記錄：打開 UsageTracker + 啟動 Service（如果你有用到）
        v.findViewById<Button>(R.id.btnStartService).setOnClickListener {
            UsageTracker.setEnabled(requireContext(), true)
            Toast.makeText(requireContext(), "已開始記錄使用行為", Toast.LENGTH_SHORT).show()

            requireContext().startService(
                Intent(requireContext(), UsageBackgroundService::class.java)
            )
        }

        // ✅ 停止記錄：關閉 UsageTracker + 停止 Service
        v.findViewById<Button>(R.id.btnStopService).setOnClickListener {
            UsageTracker.setEnabled(requireContext(), false)
            Toast.makeText(requireContext(), "已停止記錄使用行為", Toast.LENGTH_SHORT).show()

            requireContext().stopService(
                Intent(requireContext(), UsageBackgroundService::class.java)
            )
        }

        return v
    }
}
