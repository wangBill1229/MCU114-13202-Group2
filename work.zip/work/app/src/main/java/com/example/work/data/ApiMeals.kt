package com.example.work.data

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class MealNetItem(
    val id: String,
    val name: String,
    val thumb: String?
)

object ApiMeals {

    // TheMealDB: https://www.themealdb.com/api/json/v1/1/search.php?s=chicken
    fun searchMeals(keyword: String): List<MealNetItem> {
        val q = URLEncoder.encode(keyword.trim(), "UTF-8")
        val url = URL("https://www.themealdb.com/api/json/v1/1/search.php?s=$q")

        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 10_000
            readTimeout = 10_000
        }

        val code = conn.responseCode
        if (code != 200) {
            conn.disconnect()
            return emptyList()
        }

        val text = conn.inputStream.bufferedReader().use { it.readText() }
        conn.disconnect()

        val root = JSONObject(text)
        if (root.isNull("meals")) return emptyList()

        val arr = root.getJSONArray("meals")
        val out = ArrayList<MealNetItem>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.add(
                MealNetItem(
                    id = o.getString("idMeal"),
                    name = o.getString("strMeal"),
                    thumb = if (o.isNull("strMealThumb")) null else o.getString("strMealThumb")
                )
            )
        }
        return out
    }
}
