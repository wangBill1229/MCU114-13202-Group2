package com.example.work.data

import androidx.room.Entity

@Entity(
    tableName = "saved_meals",
    primaryKeys = ["mealId", "userId"]   // 同一餐點，不同使用者可各存一筆
)
data class SavedMeal(
    val mealId: String,                 // 餐點 ID（API 或你自己定義）
    val userId: Long,                   // 哪一個使用者收藏的（登入後的 userId）
    val name: String,                   // 餐點名稱
    val thumb: String?,                 // 縮圖（可為 null）
    val savedAt: Long = System.currentTimeMillis() // 收藏時間
)
