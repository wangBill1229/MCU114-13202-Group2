package com.example.work.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.work.R
import com.example.work.data.SavedMeal
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale


class SavedMealAdapter(
    private var items: List<SavedMeal>
) : RecyclerView.Adapter<SavedMealAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val tvName: TextView = v.findViewById(R.id.tvMealName)
        val tvDate: TextView = v.findViewById(R.id.tvMealDate)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_saved_meal, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.tvName.text = item.name
        holder.tvDate.text = "${formatDate(item.savedAt)}  ·  userId=${item.userId}"

    }

    override fun getItemCount(): Int = items.size

    fun update(newItems: List<SavedMeal>) {
        items = newItems
        notifyDataSetChanged()
    }

    private fun formatDate(time: Long): String {
        val sdf = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault())
        return sdf.format(Date(time))
    }
}
