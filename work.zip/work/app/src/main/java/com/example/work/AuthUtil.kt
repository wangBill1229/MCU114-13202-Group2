package com.example.work

import android.content.Context

object AuthUtil {

    private const val SP_NAME = "auth"
    private const val KEY_USER_ID = "userId"

    // 登入成功時呼叫
    fun saveUserId(context: Context, userId: Long) {
        context.getSharedPreferences(SP_NAME, Context.MODE_PRIVATE)
            .edit()
            .putLong(KEY_USER_ID, userId)
            .apply()
    }

    // 取得目前登入者
    fun getUserId(context: Context): Long {
        return context.getSharedPreferences(SP_NAME, Context.MODE_PRIVATE)
            .getLong(KEY_USER_ID, -1L)
    }

    // 登出
    fun logout(context: Context) {
        context.getSharedPreferences(SP_NAME, Context.MODE_PRIVATE)
            .edit()
            .clear()
            .apply()
    }
}
