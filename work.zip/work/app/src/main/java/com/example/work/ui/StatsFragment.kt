package com.example.work.ui

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.work.R
import com.example.work.data.DbProvider
import com.example.work.data.Feedback
import com.example.work.data.UsageTracker
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class StatsFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val v = inflater.inflate(R.layout.fragment_stats, container, false)

        val et = v.findViewById<EditText>(R.id.etFeedback)
        val btn = v.findViewById<Button>(R.id.btnSendFeedback)
        val tv = v.findViewById<TextView>(R.id.tvFeedbackResult)

        btn.setOnClickListener {
            val msg = et.text?.toString()?.trim().orEmpty()
            if (msg.isBlank()) {
                Toast.makeText(requireContext(), "請輸入回饋內容", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val userId = getCurrentUserId(requireContext())
            if (userId == -1L) {
                Toast.makeText(requireContext(), "尚未登入（userId=-1）也可先測試", Toast.LENGTH_SHORT).show()
            }

            viewLifecycleOwner.lifecycleScope.launch {
                tv.text = "狀態：送出中…"

                val newId = withContext(Dispatchers.IO) {
                    DbProvider.get(requireContext())
                        .feedbackDao()
                        .insert(Feedback(userId = userId, message = msg))
                }

                tv.text = "狀態：已送出（id=$newId）"
                Toast.makeText(requireContext(), "回饋已送出", Toast.LENGTH_SHORT).show()
                et.setText("")
            }
        }

        return v
    }

    // ✅ 改這裡：要傳 context，才會尊重「開始/停止記錄」開關
    override fun onResume() {
        super.onResume()
        UsageTracker.onEnter(requireContext())
    }

    override fun onPause() {
        super.onPause()
        val userId = getCurrentUserId(requireContext())
        UsageTracker.onExit(requireContext(), userId, "Stats")
    }

    private fun getCurrentUserId(context: Context): Long {
        val sp = context.getSharedPreferences("auth", Context.MODE_PRIVATE)
        return sp.getLong("userId", -1L)
    }
}
