package com.example.work.ui

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.work.R
import com.example.work.data.UsageTracker

class HomeFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.fragment_home, container, false)

    override fun onResume() {
        super.onResume()
        UsageTracker.onEnter(requireContext())
    }

    override fun onPause() {
        super.onPause()
        val userId = getCurrentUserId(requireContext())
        UsageTracker.onExit(requireContext(), userId, "Food")
    }


    private fun getCurrentUserId(context: Context): Long {
        val sp = context.getSharedPreferences("auth", Context.MODE_PRIVATE)
        return sp.getLong("userId", -1L)
    }
}
