package com.example.work.ui

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.work.R
import com.example.work.data.Attendance
import com.example.work.data.Course
import com.example.work.data.DbProvider
import com.example.work.data.UsageTracker
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate

class AttendanceFragment : Fragment() {

    private lateinit var adapter: AttendanceAdapter

    private lateinit var spCourse: Spinner
    private lateinit var spAdapter: ArrayAdapter<String>

    // Spinner 預設三科
    private val defaultCourses = listOf("國文", "數學", "英文")
    private val spinnerItems = mutableListOf<String>()

    private fun getCurrentUserId(context: Context): Long {
        val sp = context.getSharedPreferences("auth", Context.MODE_PRIVATE)
        return sp.getLong("userId", -1L)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val v = inflater.inflate(R.layout.fragment_attendance, container, false)

        spCourse = v.findViewById(R.id.spCourse)
        val etNewCourse = v.findViewById<EditText>(R.id.etNewCourseName)
        val btnAddCourse = v.findViewById<Button>(R.id.btnAddCourse)
        val etDate = v.findViewById<EditText>(R.id.etDate)
        val btnAdd = v.findViewById<Button>(R.id.btnAddAttendance)
        val tvSummary = v.findViewById<TextView>(R.id.tvAbsentSummary)

        val rv = v.findViewById<RecyclerView>(R.id.rvAttendance)
        rv.layoutManager = LinearLayoutManager(requireContext())

        // RecyclerView：長按刪除
        adapter = AttendanceAdapter(emptyList()) { row ->
            val uid = getCurrentUserId(requireContext())
            if (uid == -1L) return@AttendanceAdapter

            lifecycleScope.launch {
                withContext(Dispatchers.IO) {
                    DbProvider.get(requireContext())
                        .attendanceDao()
                        .deleteById(uid, row.attendanceId)
                }
                refreshList(tvSummary)
            }
        }
        rv.adapter = adapter

        // Spinner：先放預設三科
        spinnerItems.clear()
        spinnerItems.addAll(defaultCourses)
        spAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, spinnerItems)
        spAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spCourse.adapter = spAdapter

        // ✅ 進頁：先確保預設三科真的存在於 DB（只補缺的，不重複）
        val uid = getCurrentUserId(requireContext())
        if (uid != -1L) {
            lifecycleScope.launch {
                withContext(Dispatchers.IO) { ensureDefaultCoursesExist(uid) }
                syncSpinnerFromDb()
                refreshList(tvSummary)
            }
        } else {
            refreshList(tvSummary)
        }

        // 新增課程（例如：日語）
        btnAddCourse.setOnClickListener {
            val userId = getCurrentUserId(requireContext())
            if (userId == -1L) {
                Toast.makeText(requireContext(), "請先登入", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val name = etNewCourse.text.toString().trim()
            if (name.isBlank()) {
                Toast.makeText(requireContext(), "請輸入課程名稱", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            lifecycleScope.launch {
                withContext(Dispatchers.IO) {
                    val dao = DbProvider.get(requireContext()).courseDao()
                    if (dao.findByName(userId, name) == null) {
                        dao.insertCourse(
                            Course(
                                userOwnerId = userId,
                                courseName = name,
                                dayOfWeek = 1,
                                startMinute = 0,
                                endMinute = 60
                            )
                        )
                    }
                }
                Toast.makeText(requireContext(), "已新增課程：$name", Toast.LENGTH_SHORT).show()
                etNewCourse.setText("")
                syncSpinnerFromDb(selectName = name)
            }
        }

        // 新增缺席
        btnAdd.setOnClickListener {
            val userId = getCurrentUserId(requireContext())
            if (userId == -1L) {
                Toast.makeText(requireContext(), "請先登入", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val input = etDate.text.toString().trim()
            if (input.isBlank()) {
                Toast.makeText(requireContext(), "請輸入日期（MM-dd 或 yyyy-MM-dd）", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // ✅ 允許輸入 MM-dd（自動補今年），也允許直接輸入 yyyy-MM-dd
            val fullDate = if (input.length == 5 && input[2] == '-') {
                val year = LocalDate.now().year
                "$year-$input"
            } else {
                input
            }

            val courseName = spCourse.selectedItem.toString()

            lifecycleScope.launch {
                val ok = withContext(Dispatchers.IO) {
                    runCatching {
                        val db = DbProvider.get(requireContext())
                        val course = db.courseDao().findByName(userId, courseName)
                            ?: throw IllegalStateException("找不到課程：$courseName")

                        db.attendanceDao().insert(
                            Attendance(
                                userOwnerId = userId,
                                courseId = course.courseId,
                                date = fullDate,
                                status = "ABSENT"
                            )
                        )
                    }.isSuccess
                }

                if (!ok) {
                    Toast.makeText(requireContext(), "新增缺席失敗：請先新增課程", Toast.LENGTH_SHORT).show()
                    return@launch
                }

                Toast.makeText(requireContext(), "已記錄缺席：$courseName $fullDate", Toast.LENGTH_SHORT).show()
                refreshList(tvSummary)
            }
        }

        return v
    }

    // ✅ 補齊預設三科到 DB（只補缺的，不重複）
    private suspend fun ensureDefaultCoursesExist(uid: Long) {
        val db = DbProvider.get(requireContext())
        val dao = db.courseDao()

        for (name in defaultCourses) {
            if (dao.findByName(uid, name) == null) {
                dao.insertCourse(
                    Course(
                        userOwnerId = uid,
                        courseName = name,
                        dayOfWeek = 1,
                        startMinute = 0,
                        endMinute = 60
                    )
                )
            }
        }
    }

    private fun syncSpinnerFromDb(selectName: String? = null) {
        val uid = getCurrentUserId(requireContext())
        if (uid == -1L) return

        lifecycleScope.launch {
            val names = withContext(Dispatchers.IO) {
                DbProvider.get(requireContext()).courseDao().getCourseNames(uid)
            }

            val merged = LinkedHashSet<String>()
            merged.addAll(defaultCourses)
            merged.addAll(names)

            spinnerItems.clear()
            spinnerItems.addAll(merged)
            spAdapter.notifyDataSetChanged()

            selectName?.let {
                val idx = spinnerItems.indexOf(it)
                if (idx >= 0) spCourse.setSelection(idx)
            }
        }
    }

    private fun refreshList(tv: TextView) {
        val uid = getCurrentUserId(requireContext())
        if (uid == -1L) {
            tv.text = "缺席統計：請先登入"
            adapter.update(emptyList())
            return
        }

        lifecycleScope.launch {
            val db = DbProvider.get(requireContext())
            val rows = withContext(Dispatchers.IO) { db.attendanceDao().getAllWithCourseName(uid) }
            adapter.update(rows)
            tv.text = "缺席紀錄：共 ${rows.size} 筆（長按可刪除）"
        }
    }

    // ✅ 只有「已開啟記錄」才會記 enter/exit
    override fun onResume() {
        super.onResume()
        UsageTracker.onEnter(requireContext())
    }

    override fun onPause() {
        super.onPause()
        UsageTracker.onExit(
            requireContext(),
            getCurrentUserId(requireContext()),
            "Attendance"
        )
    }
}
