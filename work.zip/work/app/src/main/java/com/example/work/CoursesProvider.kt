package com.example.work

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.content.UriMatcher
import kotlinx.coroutines.runBlocking
import com.example.work.data.DbProvider

class CoursesProvider : ContentProvider() {

    companion object {
        const val AUTHORITY = "com.example.work.provider"
        private const val PATH_COURSES = "courses"
        private const val CODE_COURSES = 1

        private val matcher = UriMatcher(UriMatcher.NO_MATCH).apply {
            addURI(AUTHORITY, PATH_COURSES, CODE_COURSES)
        }
    }

    override fun onCreate(): Boolean = true

    override fun query(
        uri: Uri,
        projection: Array<out String>?,
        selection: String?,
        selectionArgs: Array<out String>?,
        sortOrder: String?
    ): Cursor? {
        if (matcher.match(uri) != CODE_COURSES) return null

        // 你可以用 query parameter 傳 userId：
        // content://com.example.work.provider/courses?userId=123
        val userId = uri.getQueryParameter("userId")?.toLongOrNull() ?: -1L

        val cursor = MatrixCursor(
            arrayOf("courseId", "userOwnerId", "courseName", "dayOfWeek", "startMinute", "endMinute", "location")
        )

        if (userId <= 0L) return cursor

        val ctx = context ?: return cursor
        val list = runBlocking {
            DbProvider.get(ctx).courseDao().getCourses(userId)
        }

        for (c in list) {
            cursor.addRow(
                arrayOf(
                    c.courseId,
                    c.userOwnerId,
                    c.courseName,
                    c.dayOfWeek,
                    c.startMinute,
                    c.endMinute,
                    c.location
                )
            )
        }
        return cursor
    }

    override fun getType(uri: Uri): String? {
        return when (matcher.match(uri)) {
            CODE_COURSES -> "vnd.android.cursor.dir/vnd.$AUTHORITY.courses"
            else -> null
        }
    }

    override fun insert(uri: Uri, values: ContentValues?): Uri? = null
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = 0
    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?): Int = 0
}
