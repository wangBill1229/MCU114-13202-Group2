package com.example.work.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface UsageDao {

    @Insert
    suspend fun insert(log: UsageLog): Long

    // 每頁總停留秒數（排行）
    @Query("""
        SELECT pageName, SUM(durationSec) AS totalSec
        FROM usage_logs
        WHERE userOwnerId = :userId
        GROUP BY pageName
        ORDER BY totalSec DESC
    """)
    suspend fun totalTimeByPage(userId: Long): List<PageTotal>
}
