package com.example.work.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface AttendanceDao {

    @Insert
    suspend fun insert(att: Attendance): Long

    // ✅ 原本：只拿 attendance（沒有課名）
    @Query("""
        SELECT * FROM attendance
        WHERE userOwnerId = :userId
        ORDER BY date DESC
    """)
    suspend fun getAll(userId: Long): List<Attendance>

    // ✅ B：JOIN courses 拿課名（給 RecyclerView 顯示用）
    @Query("""
        SELECT 
            a.attendanceId AS attendanceId,
            a.userOwnerId  AS userOwnerId,
            a.courseId     AS courseId,
            c.courseName   AS courseName,
            a.date         AS date,
            a.status       AS status
        FROM attendance a
        JOIN courses c ON c.courseId = a.courseId
        WHERE a.userOwnerId = :userId
        ORDER BY a.date DESC
    """)
    suspend fun getAllWithCourseName(userId: Long): List<AttendanceRow>

    // ✅ C：長按刪除某一筆 attendance
    @Query("""
        DELETE FROM attendance 
        WHERE userOwnerId = :userId 
          AND attendanceId = :attendanceId
    """)
    suspend fun deleteById(userId: Long, attendanceId: Long)

    // ✅ 原本：統計每門課缺席次數
    @Query("""
        SELECT courseId, COUNT(*) AS cnt
        FROM attendance
        WHERE userOwnerId = :userId AND status = 'ABSENT'
        GROUP BY courseId
        ORDER BY cnt DESC
    """)
    suspend fun absentCountByCourse(userId: Long): List<CourseCount>
}
