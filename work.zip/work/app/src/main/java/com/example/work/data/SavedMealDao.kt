package com.example.work.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface SavedMealDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(meal: SavedMeal)

    // ✅ 這裡改名：getMealsByUser
    @Query("SELECT * FROM saved_meals WHERE userId = :userId ORDER BY savedAt DESC")
    suspend fun getMealsByUser(userId: Long): List<SavedMeal>

    @Query("DELETE FROM saved_meals WHERE userId = :userId AND mealId = :mealId")
    suspend fun deleteById(userId: Long, mealId: String)
}
