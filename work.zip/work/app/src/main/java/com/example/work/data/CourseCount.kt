package com.example.work.data

data class CourseCount(
    val courseId: Long,
    val cnt: Int
)
