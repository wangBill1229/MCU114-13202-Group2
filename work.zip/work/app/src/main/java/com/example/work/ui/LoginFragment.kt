package com.example.work.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.work.AuthUtil
import com.example.work.R
import com.example.work.data.DbProvider
import com.example.work.data.User
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LoginFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val v = inflater.inflate(R.layout.fragment_login, container, false)

        val etU = v.findViewById<EditText>(R.id.etUsername)
        val etP = v.findViewById<EditText>(R.id.etPassword)
        val btnReg = v.findViewById<Button>(R.id.btnRegister)
        val btnLogin = v.findViewById<Button>(R.id.btnLogin)
        val btnLogout = v.findViewById<Button>(R.id.btnLogout)
        val tv = v.findViewById<TextView>(R.id.tvAuthStatus)

        fun updateStatus() {
            val uid = AuthUtil.getUserId(requireContext())
            tv.text = if (uid == -1L) "狀態：尚未登入" else "狀態：已登入（userId=$uid）"
            btnLogout.isEnabled = (uid != -1L)
            btnLogout.alpha = if (uid != -1L) 1f else 0.4f
        }

        updateStatus()

        // ======================
        // 註冊（成功後：自動登入 + 顯示 userId）
        // ======================
        btnReg.setOnClickListener {
            val username = etU.text?.toString()?.trim().orEmpty()
            val password = etP.text?.toString()?.trim().orEmpty()

            if (username.isBlank() || password.isBlank()) {
                Toast.makeText(requireContext(), "帳號密碼不可空白", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            viewLifecycleOwner.lifecycleScope.launch {
                val result = withContext(Dispatchers.IO) {
                    runCatching {
                        DbProvider.get(requireContext())
                            .userDao()
                            .insert(User(username = username, password = password)) // 期待回傳 newId
                    }
                }

                result.onSuccess { newId ->
                    // ✅ 直接把新註冊的使用者設為目前登入者
                    AuthUtil.saveUserId(requireContext(), newId)

                    Toast.makeText(
                        requireContext(),
                        "註冊成功並已登入（userId=$newId）",
                        Toast.LENGTH_SHORT
                    ).show()

                    updateStatus()
                }.onFailure {
                    Toast.makeText(
                        requireContext(),
                        "註冊失敗：帳號可能已存在",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }

        // ======================
        // 登入（成功後：顯示 userId）
        // ======================
        btnLogin.setOnClickListener {
            val username = etU.text?.toString()?.trim().orEmpty()
            val password = etP.text?.toString()?.trim().orEmpty()

            if (username.isBlank() || password.isBlank()) {
                Toast.makeText(requireContext(), "帳號密碼不可空白", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            viewLifecycleOwner.lifecycleScope.launch {
                val user = withContext(Dispatchers.IO) {
                    DbProvider.get(requireContext())
                        .userDao()
                        .login(username, password)
                }

                if (user == null) {
                    Toast.makeText(
                        requireContext(),
                        "登入失敗：帳號或密碼錯誤",
                        Toast.LENGTH_SHORT
                    ).show()
                    return@launch
                }

                // ✅ 關鍵：把「登入查到的那個 userId」存起來
                AuthUtil.saveUserId(requireContext(), user.userId)

                // ✅ 關鍵：吐司直接顯示目前登入 userId（用來抓 bug）
                Toast.makeText(
                    requireContext(),
                    "登入成功 userId=${user.userId}",
                    Toast.LENGTH_SHORT
                ).show()

                updateStatus()
            }
        }

        // ======================
        // 登出
        // ======================
        btnLogout.setOnClickListener {
            AuthUtil.logout(requireContext())
            Toast.makeText(requireContext(), "已登出", Toast.LENGTH_SHORT).show()
            updateStatus()
        }

        return v
    }
}
