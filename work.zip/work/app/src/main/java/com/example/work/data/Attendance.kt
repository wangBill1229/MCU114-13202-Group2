package com.example.work.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "attendance",
    foreignKeys = [
        ForeignKey(
            entity = User::class,
            parentColumns = ["userId"],
            childColumns = ["userOwnerId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = Course::class,
            parentColumns = ["courseId"],
            childColumns = ["courseId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("userOwnerId"), Index("courseId"), Index("date")]
)
data class Attendance(
    @PrimaryKey(autoGenerate = true) val attendanceId: Long = 0,
    val userOwnerId: Long,
    val courseId: Long,
    val date: String,      // "yyyy-MM-dd"
    val status: String     // "PRESENT" / "LATE" / "ABSENT"
)
