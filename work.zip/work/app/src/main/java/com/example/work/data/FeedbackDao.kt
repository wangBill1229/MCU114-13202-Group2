package com.example.work.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface FeedbackDao {

    @Insert
    suspend fun insert(feedback: Feedback): Long

    @Query("SELECT * FROM feedback ORDER BY createdAt DESC")
    suspend fun getAll(): List<Feedback>
}
