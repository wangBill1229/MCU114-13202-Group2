package com.example.work.data

data class PageTotal(
    val pageName: String,
    val totalSec: Long
)
