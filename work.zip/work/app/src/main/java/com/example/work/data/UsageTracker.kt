package com.example.work.data

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

object UsageTracker {
    private const val PREF = "usage"
    private const val KEY_ENABLED = "enabled"

    private var enterMs: Long = 0

    fun setEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_ENABLED, enabled)
            .apply()
    }

    fun isEnabled(context: Context): Boolean {
        return context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .getBoolean(KEY_ENABLED, false)
    }

    fun onEnter(context: Context) {
        if (!isEnabled(context)) return
        enterMs = System.currentTimeMillis()
    }

    fun onExit(context: Context, userId: Long, pageName: String) {
        // ✅ 沒開啟記錄就不寫
        if (!isEnabled(context)) return

        // ✅ 沒登入就不寫（避免 userId=-1 的垃圾資料）
        if (userId <= 0L) return

        // ✅ 沒有 enterMs 就不寫
        if (enterMs <= 0L) return

        val exitMs = System.currentTimeMillis()
        val durationSec = ((exitMs - enterMs) / 1000).coerceAtLeast(0)

        // ✅ 停留 0 秒也可以選擇不記（避免切一下就一筆）
        if (durationSec <= 0) return

        CoroutineScope(Dispatchers.IO).launch {
            DbProvider.get(context).usageDao().insert(
                UsageLog(
                    userOwnerId = userId,
                    pageName = pageName,
                    enterMs = enterMs,
                    exitMs = exitMs,
                    durationSec = durationSec
                )
            )
        }
    }
}
