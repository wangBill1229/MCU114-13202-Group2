package com.example.work.data

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [
        User::class,
        Course::class,
        Attendance::class,
        UsageLog::class,
        SavedMeal::class,
        Feedback::class      // ✅ 新增
    ],
    version = 4,            // ✅ 原本 2 → 改 3
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract fun courseDao(): CourseDao
    abstract fun attendanceDao(): AttendanceDao
    abstract fun usageDao(): UsageDao
    abstract fun savedMealDao(): SavedMealDao

    abstract fun feedbackDao(): FeedbackDao   // ✅ 新增
}
