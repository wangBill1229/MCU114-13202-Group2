package com.example.work.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "usage_logs",
    indices = [Index("userOwnerId"), Index("pageName")]
)
data class UsageLog(
    @PrimaryKey(autoGenerate = true) val logId: Long = 0,
    val userOwnerId: Long,
    val pageName: String,
    val enterMs: Long,
    val exitMs: Long,
    val durationSec: Long
)
