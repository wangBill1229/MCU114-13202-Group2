package com.example.work

import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.NavOptions
import androidx.navigation.fragment.NavHostFragment
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {

    private var powerReceiver: PowerReceiver? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val navHostFragment =
            supportFragmentManager.findFragmentById(R.id.nav_host) as NavHostFragment
        val navController = navHostFragment.navController

        val bottomNav = findViewById<BottomNavigationView>(R.id.bottom_nav)

        // 讓切換不會一直疊頁 + 點同一顆不重複建立
        fun go(destId: Int) {
            val options = NavOptions.Builder()
                .setLaunchSingleTop(true)
                .setPopUpTo(navController.graph.startDestinationId, false)
                .build()
            navController.navigate(destId, null, options)
        }

        // ✅ 點底部 tab -> 跳到對應頁（補上 loginFragment）
        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.menuFragment -> { go(R.id.menuFragment); true }
                R.id.loginFragment -> { go(R.id.loginFragment); true } // ✅ 新增
                R.id.attendanceFragment -> { go(R.id.attendanceFragment); true }
                R.id.foodFragment -> { go(R.id.foodFragment); true }
                R.id.statsFragment -> { go(R.id.statsFragment); true }
                else -> false
            }
        }

        // ✅ 不管用底部點 or 任何 navigate，只要目的地改變就同步底部狀態
        navController.addOnDestinationChangedListener { _, dest, _ ->
            bottomNav.visibility = View.VISIBLE // ✅ 所有頁都顯示（包含登入頁）

            when (dest.id) {
                R.id.menuFragment -> bottomNav.menu.findItem(R.id.menuFragment)?.isChecked = true
                R.id.loginFragment -> bottomNav.menu.findItem(R.id.loginFragment)?.isChecked = true
                R.id.attendanceFragment -> bottomNav.menu.findItem(R.id.attendanceFragment)?.isChecked = true
                R.id.foodFragment -> bottomNav.menu.findItem(R.id.foodFragment)?.isChecked = true
                R.id.statsFragment -> bottomNav.menu.findItem(R.id.statsFragment)?.isChecked = true
            }
        }
    }

    override fun onStart() {
        super.onStart()
        powerReceiver = PowerReceiver()
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
        }
        registerReceiver(powerReceiver, filter)
    }

    override fun onStop() {
        try {
            powerReceiver?.let { unregisterReceiver(it) }
        } catch (_: IllegalArgumentException) {
            // receiver 未註冊時，避免崩潰
        } finally {
            powerReceiver = null
        }
        super.onStop()
    }
}
