package com.example.work.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface CourseDao {

    @Insert
    suspend fun insertCourse(course: Course): Long

    @Query("""
        SELECT * FROM courses
        WHERE userOwnerId = :userId
        ORDER BY dayOfWeek, startMinute
    """)
    suspend fun getCourses(userId: Long): List<Course>

    // ✅ 用課名找該使用者的 course（給 Attendance 用）
    @Query("""
        SELECT * FROM courses
        WHERE userOwnerId = :userId AND courseName = :name
        LIMIT 1
    """)
    suspend fun findByName(userId: Long, name: String): Course?

    // ✅ 給 Spinner 用：只抓課名清單
    @Query("""
        SELECT courseName FROM courses
        WHERE userOwnerId = :userId
        ORDER BY courseName COLLATE NOCASE
    """)
    suspend fun getCourseNames(userId: Long): List<String>

    @Query("""
        DELETE FROM courses
        WHERE courseId = :courseId AND userOwnerId = :userId
    """)
    suspend fun deleteCourse(userId: Long, courseId: Long)
}
