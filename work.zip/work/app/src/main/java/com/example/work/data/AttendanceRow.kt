package com.example.work.data

data class AttendanceRow(
    val attendanceId: Long,
    val userOwnerId: Long,
    val courseId: Long,
    val courseName: String,
    val date: String,
    val status: String
)
