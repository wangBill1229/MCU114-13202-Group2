package com.example.work

import android.app.Service
import android.content.Intent
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log

class UsageBackgroundService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private val tag = "UsageBgService"

    private val task = object : Runnable {
        override fun run() {
            Log.d(tag, "Service heartbeat: ${System.currentTimeMillis()}")
            handler.postDelayed(this, 10_000) // 每 10 秒一次（demo 用）
        }
    }

    override fun onCreate() {
        super.onCreate()
        handler.post(task)
    }

    override fun onDestroy() {
        handler.removeCallbacks(task)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
