package com.example.work.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.work.R
import com.example.work.data.AttendanceRow

class AttendanceAdapter(
    private var items: List<AttendanceRow>,
    private val onLongPressDelete: (AttendanceRow) -> Unit
) : RecyclerView.Adapter<AttendanceAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val line1: TextView = v.findViewById(R.id.tvLine1)
        val line2: TextView = v.findViewById(R.id.tvLine2)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_attendance, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val a = items[position]

        // ✅ 顯示課名（不顯示 courseId）
        holder.line1.text = "課程：${a.courseName}"

        // ✅ 日期後面只顯示 userId（不顯示狀態）
        holder.line2.text = "日期：${a.date}  ·  userId=${a.userOwnerId}"

        // ✅ 長按刪除
        holder.itemView.setOnLongClickListener {
            onLongPressDelete(a)
            true
        }
    }

    override fun getItemCount(): Int = items.size

    fun update(newItems: List<AttendanceRow>) {
        items = newItems
        notifyDataSetChanged()
    }
}
