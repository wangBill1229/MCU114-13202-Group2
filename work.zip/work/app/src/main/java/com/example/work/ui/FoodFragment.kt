package com.example.work.ui

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.work.R
import com.example.work.data.ApiMeals
import com.example.work.data.DbProvider
import com.example.work.data.SavedMeal
import com.example.work.data.UsageTracker
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.lifecycle.lifecycleScope

class FoodFragment : Fragment() {

    private lateinit var adapter: SavedMealAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val v = inflater.inflate(R.layout.fragment_food, container, false)

        val et = v.findViewById<EditText>(R.id.etKeyword)
        val btn = v.findViewById<Button>(R.id.btnSearchSave)
        val tv = v.findViewById<TextView>(R.id.tvResult)

        // ✅ RecyclerView 初始化
        val rv = v.findViewById<RecyclerView>(R.id.rvMeals)
        adapter = SavedMealAdapter(emptyList())
        rv.layoutManager = LinearLayoutManager(v.context)
        rv.adapter = adapter

        // ✅ 進頁面先載入目前使用者的收藏/吃過紀錄
        val userIdAtEnter = getCurrentUserId(v.context)
        refreshList(userIdAtEnter, tv)

        btn.setOnClickListener {
            val raw = et.text?.toString()?.trim().orEmpty()
            if (raw.isBlank()) {
                Toast.makeText(v.context, "請輸入關鍵字", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val userId = getCurrentUserId(v.context)
            if (userId == -1L) {
                tv.text = "結果：請先登入再收藏"
                Toast.makeText(v.context, "請先登入再收藏", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val keyword = normalizeKeyword(raw)

            viewLifecycleOwner.lifecycleScope.launch {
                tv.text = "結果：搜尋中…"

                // 1) 網路搜尋（IO thread）
                val list = withContext(Dispatchers.IO) {
                    ApiMeals.searchMeals(keyword)
                }

                if (list.isEmpty()) {
                    tv.text = "結果：找不到資料（可試：chicken / beef / pork / rice / noodles）"
                    Toast.makeText(v.context, "找不到資料", Toast.LENGTH_SHORT).show()
                    return@launch
                }

                // 2) 存第一筆到 Room（IO thread）
                val first = list.first()
                withContext(Dispatchers.IO) {
                    DbProvider.get(v.context)
                        .savedMealDao()
                        .upsert(
                            SavedMeal(
                                mealId = first.id,
                                userId = userId,
                                name = first.name,
                                thumb = first.thumb
                            )
                        )
                }

                tv.text = "結果：已收藏 ${first.name}"
                Toast.makeText(v.context, "已收藏：${first.name}", Toast.LENGTH_LONG).show()

                // ✅ 3) 存完立刻刷新列表
                refreshList(userId, tv)
            }
        }

        return v
    }

    /**
     * ✅ 載入「目前登入使用者」的收藏/吃過紀錄並顯示在 RecyclerView
     */
    private fun refreshList(userId: Long, tv: TextView) {
        if (userId == -1L) {
            adapter.update(emptyList())
            tv.text = "結果：請先登入（下方才會顯示你的紀錄）"
            return
        }

        viewLifecycleOwner.lifecycleScope.launch {
            val meals = withContext(Dispatchers.IO) {
                DbProvider.get(requireContext())
                    .savedMealDao()
                    .getMealsByUser(userId)
            }

            adapter.update(meals)

            if (meals.isEmpty()) {
                tv.text = "結果：目前沒有紀錄（先搜尋並儲存一筆）"
            }
        }
    }

    /**
     * ✅ 讓你可以中文輸入，也能自動變成 API 常吃的英文關鍵字
     * 找不到對應就回傳原字，讓英文照樣可用
     */
    private fun normalizeKeyword(input: String): String {
        val map = mapOf(
            "雞" to "chicken",
            "雞肉" to "chicken",
            "牛" to "beef",
            "牛肉" to "beef",
            "豬" to "pork",
            "豬肉" to "pork",
            "魚" to "fish",
            "麵" to "noodles",
            "拉麵" to "noodles",
            "飯" to "rice",
            "沙拉" to "salad",
            "湯" to "soup",
            "蛋" to "egg",
            "起司" to "cheese",
            "馬鈴薯" to "potato"
        )
        return map[input] ?: input
    }

    override fun onResume() {
        super.onResume()
        UsageTracker.onEnter(requireContext())
    }

    override fun onPause() {
        super.onPause()
        val userId = getCurrentUserId(requireContext())
        UsageTracker.onExit(requireContext(), userId, "Food")
    }


    private fun getCurrentUserId(context: Context): Long {
        val sp = context.getSharedPreferences("auth", Context.MODE_PRIVATE)
        return sp.getLong("userId", -1L)
    }
}
